var user = [
    {
        user:"shamil",
        pass:"123456"
    }
];


module.exports=user;